package mslinks;

public class ShellLinkException extends Exception {
	public ShellLinkException() {
		super();
	}
	
	public ShellLinkException(String msg) {
		super(msg);
	}
}
