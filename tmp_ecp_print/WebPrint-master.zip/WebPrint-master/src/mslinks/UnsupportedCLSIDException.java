package mslinks;

public class UnsupportedCLSIDException extends ShellLinkException {

}
